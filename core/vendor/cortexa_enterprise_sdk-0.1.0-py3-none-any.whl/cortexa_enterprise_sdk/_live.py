"""
_live.py

Bidirectional, real-time WebSocket connection management for live sessions using App ID and Client Secret headers.
"""

import json
from collections.abc import AsyncIterator
from types import TracebackType

from websockets.asyncio.client import ClientConnection, connect
from websockets.exceptions import WebSocketException

from ._exceptions import APIConnectionError, CortexaError
from .types.live import LiveConnectConfig, LiveServerContent, LiveServerResponse


class LiveSession:
    """Bidirectional read/write session over an active WebSocket connection."""

    def __init__(
        self,
        websocket: ClientConnection,
        config: LiveConnectConfig | None = None,
    ) -> None:
        self._ws = websocket
        self._config = config

    async def send(
        self,
        input: str | None = None,
        *,
        text: str | None = None,
        end_of_turn: bool = True,
        metadata: dict[str, object] | None = None,
    ) -> None:
        """Send input over the persistent live connection."""
        prompt = input if input is not None else text
        if prompt is None:
            raise ValueError("send() requires an 'input' or 'text' argument.")

        payload = {
            "input": prompt,
            "end_of_turn": end_of_turn,
            "metadata": metadata or {},
            "config": self._config.model_dump() if self._config else None,
        }

        try:
            await self._ws.send(json.dumps(payload))
        except WebSocketException as e:
            raise APIConnectionError(
                f"Failed to send data over WebSocket connection: {e}"
            ) from e

    async def receive(self) -> AsyncIterator[LiveServerResponse]:
        """Yield parsed responses as they stream from the server."""
        try:
            async for message in self._ws:
                if isinstance(message, bytes):
                    message = message.decode("utf-8")

                try:
                    raw_json = json.loads(message)
                except json.JSONDecodeError as e:
                    raise CortexaError(
                        f"Received malformed JSON from WebSocket server: {e}"
                    ) from e

                server_content_data = raw_json.get("server_content") or {}
                yield LiveServerResponse(
                    type=raw_json.get("type", "server_content"),
                    server_content=LiveServerContent(**server_content_data),
                    raw_data=raw_json,
                )
        except WebSocketException as e:
            raise APIConnectionError(f"Live WebSocket connection dropped: {e}") from e


class LiveContextManager:
    """Async context manager for managing persistent WebSocket lifecycle."""

    def __init__(
        self,
        ws_url: str,
        app_id: str,
        client_secret: str,
        config: LiveConnectConfig | None = None,
    ) -> None:
        self.ws_url = ws_url
        self.app_id = app_id
        self.client_secret = client_secret
        self.config = config
        self._ws: ClientConnection | None = None

    async def __aenter__(self) -> LiveSession:
        try:
            self._ws = await connect(
                self.ws_url,
                additional_headers={
                    "App-ID": self.app_id,
                    "Client-Secret": self.client_secret,
                },
            )
            return LiveSession(self._ws, self.config)
        except WebSocketException as e:
            raise APIConnectionError(
                f"Could not establish WebSocket connection to {self.ws_url}: {e}"
            ) from e

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        if self._ws is not None:
            await self._ws.close()


class LiveManager:
    """Namespace client resource for creating live sessions."""

    def __init__(self, app_id: str, client_secret: str, ws_url: str) -> None:
        self._app_id = app_id
        self._client_secret = client_secret
        self._ws_url = ws_url

    def connect(
        self,
        config: LiveConnectConfig | None = None,
    ) -> LiveContextManager:
        """Initialize a live context manager session."""
        return LiveContextManager(
            ws_url=self._ws_url,
            app_id=self._app_id,
            client_secret=self._client_secret,
            config=config,
        )
