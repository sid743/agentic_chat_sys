"""
_base_client.py

HTTP transport layer handling connection management, request retries,
authentication headers, and exception mapping.
"""

from __future__ import annotations

import asyncio
import os
import time
from types import TracebackType
from typing import Self, cast

import httpx

from ._exceptions import (
    APIConnectionError,
    APIStatusError,
    AuthenticationError,
    BadRequestError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
)

DEFAULT_BASE_URL: str = os.getenv("CORTEXA_CORE_BASE_URL", "")
DEFAULT_TIMEOUT: float = 60.0
DEFAULT_MAX_RETRIES: int = 2
RETRYABLE_STATUS_CODES: set[int] = {429, 500, 502, 503, 504}


def _raise_for_status(resp: httpx.Response) -> None:
    """Map HTTP status codes to specific Cortexa exception subclasses."""
    if resp.status_code < 400:
        return

    body = resp.text
    status = resp.status_code

    if status == 401:
        raise AuthenticationError(
            "Invalid or missing App ID or client secret", status, body
        )
    if status == 403:
        raise PermissionDeniedError(
            "Credentials unauthorized for this action", status, body
        )
    if status == 404:
        raise NotFoundError("Requested resource not found", status, body)
    if status in (400, 422):
        raise BadRequestError(f"Request validation failed: {body}", status, body)
    if status == 429:
        raise RateLimitError("Rate limit exceeded, back off requests", status, body)
    if status >= 500:
        raise InternalServerError(f"Cortexa server error: {body}", status, body)

    raise APIStatusError(f"Unexpected API error {status}: {body}", status, body)


class BaseClient:
    """Synchronous HTTP transport for Cortexa Enterprise SDK clients."""

    def __init__(
        self,
        app_id: str | None = None,
        client_secret: str | None = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        _base_url_override: str | None = None,
        _CORTEXA_CORE_BASE_URL_override: str | None = None,
    ) -> None:
        self.app_id = app_id or os.getenv("CORTEXA_APP_ID", "")
        self.client_secret = client_secret or os.getenv("CORTEXA_CLIENT_SECRET", "")

        if not self.app_id or not self.client_secret:
            raise AuthenticationError(
                "App ID and Client Secret must be provided or set via CORTEXA_APP_ID and CORTEXA_CLIENT_SECRET environment variables."
            )

        resolved_base = (
            _base_url_override
            or _CORTEXA_CORE_BASE_URL_override
            or os.getenv("CORTEXA_CORE_BASE_URL")
            or DEFAULT_BASE_URL
        )
        self.base_url = resolved_base.rstrip("/")
        self.max_retries = max_retries
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "App-ID": self.app_id,
                "Client-Secret": self.client_secret,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    @property
    def ws_base_url(self) -> str:
        """Derive WebSocket base URL (ws:// or wss://) from HTTP base URL."""
        if self.base_url.startswith("https://"):
            return "wss://" + self.base_url[8:]
        if self.base_url.startswith("http://"):
            return "ws://" + self.base_url[7:]
        return f"wss://{self.base_url}"

    def get(self, path: str) -> dict[str, object]:
        """Send GET request with exponential backoff for retriable failures."""
        last_error: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                resp = self._client.get(path)
            except httpx.RequestError as e:
                last_error = APIConnectionError(
                    f"Could not connect to {self.base_url}: {e}"
                )
                if attempt < self.max_retries:
                    time.sleep(2**attempt)
                    continue
                raise last_error from e

            if (
                resp.status_code in RETRYABLE_STATUS_CODES
                and attempt < self.max_retries
            ):
                time.sleep(2**attempt)
                continue

            _raise_for_status(resp)
            return cast(dict[str, object], resp.json())

        raise last_error or APIConnectionError("Request failed after max retries")

    def post(self, path: str, json: dict[str, object]) -> dict[str, object]:
        """Send POST request with exponential backoff for retriable failures."""
        last_error: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                resp = self._client.post(path, json=json)
            except httpx.RequestError as e:
                last_error = APIConnectionError(
                    f"Could not connect to {self.base_url}: {e}"
                )
                if attempt < self.max_retries:
                    time.sleep(2**attempt)
                    continue
                raise last_error from e

            if (
                resp.status_code in RETRYABLE_STATUS_CODES
                and attempt < self.max_retries
            ):
                time.sleep(2**attempt)
                continue

            _raise_for_status(resp)
            return cast(dict[str, object], resp.json())

        raise last_error or APIConnectionError("Request failed after max retries")

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()


class AsyncBaseClient:
    """Asynchronous HTTP transport for Cortexa Enterprise SDK clients."""

    def __init__(
        self,
        app_id: str | None = None,
        client_secret: str | None = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        _base_url_override: str | None = None,
        _CORTEXA_CORE_BASE_URL_override: str | None = None,
    ) -> None:
        self.app_id = app_id or os.getenv("CORTEXA_APP_ID", "")
        self.client_secret = client_secret or os.getenv("CORTEXA_CLIENT_SECRET", "")

        if not self.app_id or not self.client_secret:
            raise AuthenticationError(
                "App ID and Client Secret must be provided or set via CORTEXA_APP_ID and CORTEXA_CLIENT_SECRET environment variables."
            )

        resolved_base = (
            _base_url_override
            or _CORTEXA_CORE_BASE_URL_override
            or os.getenv("CORTEXA_CORE_BASE_URL")
            or DEFAULT_BASE_URL
        )
        self.base_url = resolved_base.rstrip("/")
        self.max_retries = max_retries
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "App-ID": self.app_id,
                "Client-Secret": self.client_secret,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    @property
    def ws_base_url(self) -> str:
        """Derive WebSocket base URL (ws:// or wss://) from HTTP base URL."""
        if self.base_url.startswith("https://"):
            return "wss://" + self.base_url[8:]
        if self.base_url.startswith("http://"):
            return "ws://" + self.base_url[7:]
        return f"wss://{self.base_url}"

    async def get(self, path: str) -> dict[str, object]:
        """Send async GET request with exponential backoff for retriable failures."""
        last_error: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                resp = await self._client.get(path)
            except httpx.RequestError as e:
                last_error = APIConnectionError(
                    f"Could not connect to {self.base_url}: {e}"
                )
                if attempt < self.max_retries:
                    await asyncio.sleep(2**attempt)
                    continue
                raise last_error from e

            if (
                resp.status_code in RETRYABLE_STATUS_CODES
                and attempt < self.max_retries
            ):
                await asyncio.sleep(2**attempt)
                continue

            _raise_for_status(resp)
            return cast(dict[str, object], resp.json())

        raise last_error or APIConnectionError("Request failed after max retries")

    async def post(self, path: str, json: dict[str, object]) -> dict[str, object]:
        """Send async POST request with exponential backoff for retriable failures."""
        last_error: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                resp = await self._client.post(path, json=json)
            except httpx.RequestError as e:
                last_error = APIConnectionError(
                    f"Could not connect to {self.base_url}: {e}"
                )
                if attempt < self.max_retries:
                    await asyncio.sleep(2**attempt)
                    continue
                raise last_error from e

            if (
                resp.status_code in RETRYABLE_STATUS_CODES
                and attempt < self.max_retries
            ):
                await asyncio.sleep(2**attempt)
                continue

            _raise_for_status(resp)
            return cast(dict[str, object], resp.json())

        raise last_error or APIConnectionError("Request failed after max retries")

    async def close(self) -> None:
        """Close the underlying async HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()
