"""
cortexa_enterprise_sdk

Public entry points and types for the Cortexa Enterprise Core Python SDK.
"""

from __future__ import annotations

from ._client import (
    AsyncCortexaClient,
    AsyncCortexaEnterpriseClient,
    CortexaClient,
    CortexaEnterpriseClient,
)
from ._exceptions import (
    APIConnectionError,
    APIStatusError,
    AuthenticationError,
    BadRequestError,
    CortexaError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
)
from ._version import __version__
from .types.live import LiveConnectConfig, LiveServerContent, LiveServerResponse
from .types.request import PrismRequest, SessionMetadata
from .types.response import PrismResponse

# Convenience Aliases
Cortexa = CortexaEnterpriseClient
AsyncCortexa = AsyncCortexaEnterpriseClient

__all__ = [
    "APIConnectionError",
    "APIStatusError",
    "AsyncCortexa",
    "AsyncCortexaClient",
    "AsyncCortexaEnterpriseClient",
    "AuthenticationError",
    "BadRequestError",
    "Cortexa",
    "CortexaClient",
    "CortexaEnterpriseClient",
    "CortexaError",
    "InternalServerError",
    "LiveConnectConfig",
    "LiveServerContent",
    "LiveServerResponse",
    "NotFoundError",
    "PermissionDeniedError",
    "PrismRequest",
    "PrismResponse",
    "RateLimitError",
    "SessionMetadata",
    "__version__",
]
