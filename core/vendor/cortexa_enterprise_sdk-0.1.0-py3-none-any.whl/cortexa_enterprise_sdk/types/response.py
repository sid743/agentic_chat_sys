"""
types/response.py

Type schemas for interaction responses returned by Cortexa Core.
"""

from __future__ import annotations

import json

from pydantic import BaseModel, ConfigDict


class PrismResponse(BaseModel):
    query: str
    response: str
    ai_metadata: dict[str, object] | None = None
    decision_gate: dict[str, object] | None = None
    intent_classifier: dict[str, object] | None = None
    workload_classifier: dict[str, object] | None = None
    collector: dict[str, object] | None = None
    challenger: dict[str, object] | None = None
    planner: dict[str, object] | None = None
    communicator: dict[str, object] | None = None
    composer: dict[str, object] | None = None

    model_config = ConfigDict(extra="allow")

    def __str__(self) -> str:
        """
        If modules are cleared (standard invoke), print just the response text.
        If modules are present (invoke_prism), print the full pretty JSON payload.
        """
        if self.ai_metadata is None:
            return self.response
        return json.dumps(self.model_dump(), indent=2)

    def to_json(self, indent: int = 2) -> str:
        """Explicitly export the full response structure as a pretty-printed JSON string."""
        return json.dumps(self.model_dump(), indent=indent)


class HeartbeatResponse(BaseModel):
    status: str
    message: str

    model_config = ConfigDict(extra="allow")

    def __str__(self) -> str:
        return json.dumps(self.model_dump(), indent=2)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.model_dump(), indent=indent)
