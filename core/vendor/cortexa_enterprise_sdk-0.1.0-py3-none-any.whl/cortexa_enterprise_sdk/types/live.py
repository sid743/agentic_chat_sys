"""
types/live.py

Type schemas for real-time WebSocket / Live API sessions.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class LiveConnectConfig(BaseModel):
    """Configuration options when establishing a live session."""

    response_modalities: list[str] = Field(default=["TEXT"])
    system_instruction: str | None = None


class LiveServerContent(BaseModel):
    """Content emitted by Cortexa Core during live execution."""

    text: str | None = None
    node: str | None = None  # e.g., "DecisionGate", "Composer"
    status: str | None = None
    turn_complete: bool = False


class LiveServerResponse(BaseModel):
    """Encapsulates WebSocket server events and streaming frames."""

    type: str  # e.g., "server_content", "system", "error"
    server_content: LiveServerContent | None = None
    raw_data: dict[str, object] | None = Field(default=None, exclude=True)

    @property
    def text(self) -> str:
        """Convenience property to extract text payload from server content."""
        if self.server_content and self.server_content.text:
            return self.server_content.text
        return ""
