"""
types/heartbeat.py

Type schemas for health-check (heartbeat) responses from Cortexa Core.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class HeartbeatResponse(BaseModel):
    """Response returned by the health-check heartbeat endpoint."""

    status: str = Field(..., description="Status indicator, e.g., 'connected' or 'ok'.")
    message: str | None = Field(
        default=None, description="Optional informational message."
    )
