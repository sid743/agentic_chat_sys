"""
types/request.py

Type schemas for outgoing payloads sent to Cortexa Core API endpoints.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class SessionMetadata(BaseModel):
    """Optional tracking metadata attached to an interaction request."""

    session_id: str | None = Field(
        default=None, description="Groups requests into a single conversation context."
    )
    user_id: str | None = Field(
        default=None, description="Identifies the specific end-user making the call."
    )
    trace_id: str | None = Field(
        default=None, description="Correlation ID for distributed tracing."
    )


class PrismRequest(BaseModel):
    """Request payload for /api/core/event and /api/core/prism-event."""

    query: str = Field(
        ..., description="Natural language prompt or instruction for Cortexa Core."
    )
    session_metadata: SessionMetadata | None = Field(
        default=None, description="Optional conversation and tracing context."
    )
