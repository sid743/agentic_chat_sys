"""
_exceptions.py

Exception hierarchy for Cortexa Enterprise SDK errors.
"""

from __future__ import annotations


class CortexaError(Exception):
    """Base class for all exceptions raised by the Cortexa Enterprise SDK."""


class APIConnectionError(CortexaError):
    """Raised when the SDK cannot establish a connection to Cortexa Core."""


class APIStatusError(CortexaError):
    """
    Raised when Cortexa Core responds with a non-2xx status code.

    Attributes:
        status_code (int | None): The HTTP status code returned by the server.
        response_body (str): The raw response body string.
    """

    def __init__(
        self, message: str, status_code: int | None = None, response_body: str = ""
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(status_code={self.status_code}, message={str(self)!r})"


class AuthenticationError(APIStatusError):
    """Raised on HTTP 401 or missing client credentials errors."""

    def __init__(
        self, message: str, status_code: int | None = 401, response_body: str = ""
    ) -> None:
        super().__init__(message, status_code=status_code, response_body=response_body)


class PermissionDeniedError(APIStatusError):
    """Raised on HTTP 403 - Credentials lack permission for the action."""

    def __init__(
        self, message: str, status_code: int | None = 403, response_body: str = ""
    ) -> None:
        super().__init__(message, status_code=status_code, response_body=response_body)


class NotFoundError(APIStatusError):
    """Raised on HTTP 404 - Requested resource was not found."""

    def __init__(
        self, message: str, status_code: int | None = 404, response_body: str = ""
    ) -> None:
        super().__init__(message, status_code=status_code, response_body=response_body)


class BadRequestError(APIStatusError):
    """Raised on HTTP 400 / 422 - Request payload failed validation."""

    def __init__(
        self, message: str, status_code: int | None = 400, response_body: str = ""
    ) -> None:
        super().__init__(message, status_code=status_code, response_body=response_body)


class RateLimitError(APIStatusError):
    """Raised on HTTP 429 - Rate limit exceeded."""

    def __init__(
        self, message: str, status_code: int | None = 429, response_body: str = ""
    ) -> None:
        super().__init__(message, status_code=status_code, response_body=response_body)


class InternalServerError(APIStatusError):
    """Raised on HTTP 5xx - Internal server error in Cortexa Core."""

    def __init__(
        self, message: str, status_code: int | None = 500, response_body: str = ""
    ) -> None:
        super().__init__(message, status_code=status_code, response_body=response_body)
