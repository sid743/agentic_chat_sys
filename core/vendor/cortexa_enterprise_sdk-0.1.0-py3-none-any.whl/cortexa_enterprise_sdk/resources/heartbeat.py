"""
resources/heartbeat.py

Manages lightweight heartbeat and health-check interactions with Cortexa Core and local environments.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

import httpx

from ..types.heartbeat import HeartbeatResponse

if TYPE_CHECKING:
    from .._base_client import AsyncBaseClient, BaseClient

# Endpoint path for heartbeat health check and environment configurations
HEARTBEAT_PATH = "/api/core/ping"
LOCAL_DEFAULT_URL = os.getenv("CORTEXA_LOCAL_URL", "http://127.0.0.1:8000")
DEFAULT_BASE_URL = os.getenv(
    "CORTEXA_CORE_BASE_URL", "https://dev.cortexaenterprise.ai"
)


class HeartbeatResource:
    """Synchronous resource for health checks across core and local environments."""

    def __init__(self, client: BaseClient) -> None:
        self._client = client

    def heartbeat(
        self, check_local: bool = False
    ) -> HeartbeatResponse | dict[str, object]:
        """
        Verify connection and authentication status with Cortexa Core via heartbeat.
        If check_local is True, also verifies connection against local or environment endpoints.
        """
        base_url = os.getenv("CORTEXA_CORE_BASE_URL", DEFAULT_BASE_URL)

        # Primary core heartbeat using client post method
        primary_data = self._client.post(HEARTBEAT_PATH, json={})
        primary_response = HeartbeatResponse.model_validate(primary_data)

        if not check_local:
            return primary_response

        # Optional local/target check using base URL with explicit dict[str, object] typing
        local_result: dict[str, object] = {
            "core": primary_response.model_dump(),
            "local": None,
        }
        try:
            target_url = f"{base_url.rstrip('/')}{HEARTBEAT_PATH}"
            with httpx.Client(timeout=3.0) as temp_client:
                # Use post to match backend route method
                resp = temp_client.post(target_url, json={})
                if resp.status_code == 200:
                    local_result["local"] = resp.json()
                else:
                    local_result["local"] = {
                        "status": "error",
                        "code": resp.status_code,
                    }
        except (httpx.RequestError, OSError) as e:
            local_result["local"] = {"status": "unreachable", "error": str(e)}

        return local_result


class AsyncHeartbeatResource:
    """Asynchronous resource for health checks across core and local environments."""

    def __init__(self, client: AsyncBaseClient) -> None:
        self._client = client

    async def heartbeat(
        self, check_local: bool = False
    ) -> HeartbeatResponse | dict[str, object]:
        """
        Verify connection and authentication status with Cortexa Core asynchronously via heartbeat.
        If check_local is True, also verifies connection against local or environment endpoints.
        """
        base_url = os.getenv("CORTEXA_CORE_BASE_URL", DEFAULT_BASE_URL)

        primary_data = await self._client.post(HEARTBEAT_PATH, json={})
        primary_response = HeartbeatResponse.model_validate(primary_data)

        if not check_local:
            return primary_response

        local_result: dict[str, object] = {
            "core": primary_response.model_dump(),
            "local": None,
        }
        try:
            target_url = f"{base_url.rstrip('/')}{HEARTBEAT_PATH}"
            async with httpx.AsyncClient(timeout=3.0) as temp_client:
                resp = await temp_client.post(target_url, json={})
                if resp.status_code == 200:
                    local_result["local"] = resp.json()
                else:
                    local_result["local"] = {
                        "status": "error",
                        "code": resp.status_code,
                    }
        except (httpx.RequestError, OSError) as e:
            local_result["local"] = {"status": "unreachable", "error": str(e)}

        return local_result
