"""
resources/response.py

Manages interaction execution endpoints: standard event, detailed prism-event, and heartbeat/health check.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from pydantic import ValidationError

from ..types.response import HeartbeatResponse, PrismResponse

if TYPE_CHECKING:
    from .._base_client import AsyncBaseClient, BaseClient

# Core API Endpoint Routes
EVENT_PATH = "/api/core/event"
EVENT_PRISM_PATH = "/api/core/prism-event"
HEARTBEAT_PATH = "/api/core/heartbeat"


EntrypointType = Literal["event", "prism-event", "heartbeat"]


def _build_payload(
    query: str,
    session_id: str | None = None,
    user_id: str | None = None,
    trace_id: str | None = None,
) -> dict[str, object]:
    """Construct request payload with optional session metadata."""
    payload: dict[str, object] = {"query": query}
    if session_id or user_id or trace_id:
        payload["session_metadata"] = {
            "session_id": session_id,
            "user_id": user_id,
            "trace_id": trace_id,
        }
    return payload


def _resolve_endpoint(entrypoint: str) -> str:
    """Resolve endpoint path from entrypoint string."""
    if entrypoint in ("event", "EVENT"):
        return EVENT_PATH
    if entrypoint in ("prism-event", "PRISM_EVENT"):
        return EVENT_PRISM_PATH
    if entrypoint in ("heartbeat", "HEARTBEAT"):
        return HEARTBEAT_PATH
    raise ValueError(
        f"Invalid entrypoint '{entrypoint}'. Expected 'event', 'prism-event', or 'heartbeat'."
    )


def _parse_response(
    data: dict[str, object], query: str, entrypoint: str
) -> PrismResponse:
    """Parse JSON response into PrismResponse model cleanly without side effects."""
    try:
        parsed = PrismResponse.model_validate(data)
    except (ValidationError, ValueError, KeyError, TypeError):
        raw_text = (
            data.get("response") or data.get("answer") or data.get("output") or ""
        )
        text = str(raw_text) if raw_text is not None else ""

        raw_query = data.get("query", query)
        resolved_query = str(raw_query) if isinstance(raw_query, str) else query

        parsed = PrismResponse(query=resolved_query, response=text)

    if entrypoint == "event":
        parsed.ai_metadata = None
        parsed.decision_gate = None
        parsed.intent_classifier = None
        parsed.workload_classifier = None
        parsed.collector = None
        parsed.challenger = None
        parsed.planner = None
        parsed.communicator = None
        parsed.composer = None

    return parsed


class ResponseResource:
    """Synchronous resource for Cortexa Enterprise Core interactions."""

    def __init__(self, client: BaseClient) -> None:
        self._client = client

    def create(
        self,
        query: str,
        *,
        session_id: str | None = None,
        user_id: str | None = None,
        trace_id: str | None = None,
        entrypoint: EntrypointType = "event",
    ) -> PrismResponse:
        payload = _build_payload(query, session_id, user_id, trace_id)
        endpoint = _resolve_endpoint(entrypoint)
        response_data = self._client.post(endpoint, json=payload)
        return _parse_response(response_data, query, entrypoint)

    def prism_event(
        self,
        query: str,
        *,
        session_id: str | None = None,
        user_id: str | None = None,
        trace_id: str | None = None,
    ) -> PrismResponse:
        """Convenience alias for create(..., entrypoint="prism-event")."""
        return self.create(
            query,
            session_id=session_id,
            user_id=user_id,
            trace_id=trace_id,
            entrypoint="prism-event",
        )

    def heartbeat(self) -> HeartbeatResponse:
        """Check core API connection health status."""
        response_data = self._client.get(HEARTBEAT_PATH)
        try:
            return HeartbeatResponse.model_validate(response_data)
        except (ValidationError, ValueError):
            raw_status = (
                response_data.get("status") if isinstance(response_data, dict) else None
            )
            raw_msg = (
                response_data.get("message")
                if isinstance(response_data, dict)
                else None
            )

            status_val = raw_status if isinstance(raw_status, str) else "ok"
            msg_val = raw_msg if isinstance(raw_msg, str) else "pong"

            return HeartbeatResponse(status=status_val, message=msg_val)


class AsyncResponseResource:
    """Asynchronous resource for Cortexa Enterprise Core interactions."""

    def __init__(self, client: AsyncBaseClient) -> None:
        self._client = client

    async def create(
        self,
        query: str,
        *,
        session_id: str | None = None,
        user_id: str | None = None,
        trace_id: str | None = None,
        entrypoint: EntrypointType = "event",
    ) -> PrismResponse:
        payload = _build_payload(query, session_id, user_id, trace_id)
        endpoint = _resolve_endpoint(entrypoint)
        response_data = await self._client.post(endpoint, json=payload)
        return _parse_response(response_data, query, entrypoint)

    async def prism_event(
        self,
        query: str,
        *,
        session_id: str | None = None,
        user_id: str | None = None,
        trace_id: str | None = None,
    ) -> PrismResponse:
        """Async convenience alias for create(..., entrypoint="prism-event")."""
        return await self.create(
            query,
            session_id=session_id,
            user_id=user_id,
            trace_id=trace_id,
            entrypoint="prism-event",
        )

    async def heartbeat(self) -> HeartbeatResponse:
        """Async check core API connection health status."""
        response_data = await self._client.get(HEARTBEAT_PATH)
        try:
            return HeartbeatResponse.model_validate(response_data)
        except (ValidationError, ValueError):
            raw_status = (
                response_data.get("status") if isinstance(response_data, dict) else None
            )
            raw_msg = (
                response_data.get("message")
                if isinstance(response_data, dict)
                else None
            )

            status_val = raw_status if isinstance(raw_status, str) else "ok"
            msg_val = raw_msg if isinstance(raw_msg, str) else "pong"

            return HeartbeatResponse(status=status_val, message=msg_val)
