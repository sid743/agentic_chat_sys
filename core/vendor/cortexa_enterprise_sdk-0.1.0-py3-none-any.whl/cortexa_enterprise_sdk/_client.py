"""
_client.py

Public client entry points for Cortexa Enterprise SDK: CortexaEnterpriseClient and AsyncCortexaEnterpriseClient.
"""

from __future__ import annotations

import os

from ._base_client import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    AsyncBaseClient,
    BaseClient,
)
from ._exceptions import AuthenticationError
from ._live import LiveManager
from .resources.heartbeat import AsyncHeartbeatResource, HeartbeatResource
from .resources.response import AsyncResponseResource, ResponseResource


class CortexaEnterpriseClient(BaseClient):
    """
    Synchronous client for Cortexa Core API using App ID and Client Secret.

    Args:
        app_id: Optional App ID. Defaults to CORTEXA_APP_ID environment variable.
        client_secret: Optional Client Secret. Defaults to CORTEXA_CLIENT_SECRET environment variable.
        timeout: Per-request timeout in seconds. Defaults to 60.0s.
        max_retries: Maximum automatic retries on transient errors. Defaults to 2.
    """

    def __init__(
        self,
        app_id: str | None = None,
        client_secret: str | None = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        **_internal_kwargs: object,
    ) -> None:
        base_url_override: str | None = None
        if "_base_url_override" in _internal_kwargs:
            val = _internal_kwargs.pop("_base_url_override")
            if isinstance(val, str):
                base_url_override = val

        resolved_app_id = app_id or os.getenv("CORTEXA_APP_ID")
        resolved_client_secret = client_secret or os.getenv("CORTEXA_CLIENT_SECRET")

        if not resolved_app_id or not resolved_client_secret:
            raise AuthenticationError(
                "App ID and Client Secret must be provided or set in CORTEXA_APP_ID and CORTEXA_CLIENT_SECRET environment variables.",
                status_code=401,
            )

        super().__init__(
            app_id=resolved_app_id,
            client_secret=resolved_client_secret,
            timeout=timeout,
            max_retries=max_retries,
            _base_url_override=base_url_override,
        )

        self.heartbeat = HeartbeatResource(self)
        self.interactions = ResponseResource(self)


class AsyncCortexaEnterpriseClient(AsyncBaseClient):
    """
    Asynchronous client for Cortexa Core API using App ID and Client Secret.

    Args:
        app_id: Optional App ID. Defaults to CORTEXA_APP_ID environment variable.
        client_secret: Optional Client Secret. Defaults to CORTEXA_CLIENT_SECRET environment variable.
        timeout: Per-request timeout in seconds. Defaults to 60.0s.
        max_retries: Maximum automatic retries on transient errors. Defaults to 2.
    """

    def __init__(
        self,
        app_id: str | None = None,
        client_secret: str | None = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        **_internal_kwargs: object,
    ) -> None:
        base_url_override: str | None = None
        if "_base_url_override" in _internal_kwargs:
            val = _internal_kwargs.pop("_base_url_override")
            if isinstance(val, str):
                base_url_override = val

        resolved_app_id = app_id or os.getenv("CORTEXA_APP_ID")
        resolved_client_secret = client_secret or os.getenv("CORTEXA_CLIENT_SECRET")

        if not resolved_app_id or not resolved_client_secret:
            raise AuthenticationError(
                "App ID and Client Secret must be provided or set in CORTEXA_APP_ID and CORTEXA_CLIENT_SECRET environment variables.",
                status_code=401,
            )

        super().__init__(
            app_id=resolved_app_id,
            client_secret=resolved_client_secret,
            timeout=timeout,
            max_retries=max_retries,
            _base_url_override=base_url_override,
        )

        self.heartbeat = AsyncHeartbeatResource(self)
        self.interactions = AsyncResponseResource(self)

        # Utilize the ws_base_url property from AsyncBaseClient
        self._ws_url = f"{self.ws_base_url}/api/core/ws"

        # Ensure non-null assertions for mypy compatibility
        assert self.app_id is not None
        assert self.client_secret is not None

        self.live = LiveManager(
            app_id=self.app_id,
            client_secret=self.client_secret,
            ws_url=self._ws_url,
        )


# Legacy aliases
CortexaClient = CortexaEnterpriseClient
AsyncCortexaClient = AsyncCortexaEnterpriseClient
AsyncCortexa = CortexaEnterpriseClient
